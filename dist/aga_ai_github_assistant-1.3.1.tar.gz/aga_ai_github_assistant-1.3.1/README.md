# AGA — AI GitHub Assistant

An AI-powered GitHub assistant that automates file deployment, repository analysis, README generation, and commit messages — all from a clean web UI or CLI.

---

## Features

- **AI File Deployment** — Upload files and push them directly to any GitHub repository with an AI-generated commit message
- **Repo Manager** — Browse, navigate, and manage your GitHub repositories and files from a visual explorer
- **Deep Analyzer** — Get AI-powered health scores and architectural reports for any public or private repository
- **Smart README Generator** — Generate professional README files in multiple styles (professional, startup, minimal, etc.)
- **Repo Creator** — Create new GitHub repositories directly from the UI
- **CLI Support** — Run core features from the terminal using the `aga` command

---

## Tech Stack

- **UI** — [Gradio](https://gradio.app)
- **AI** — [Groq](https://groq.com) + [LangChain](https://langchain.com) (Llama 3.3 70B)
- **GitHub API** — [PyGithub](https://pygithub.readthedocs.io)
- **CLI** — [Click](https://click.palletsprojects.com)

---

## Installation

```bash
pip install aga-ai-github-assistant
```

---

## Quick Start

### Web UI

```bash
py -m app.main
```

Then open your browser at `http://127.0.0.1:7860`

### CLI

```bash
# Create a repository
aga create-repo my-new-repo --description "My project" --public

# Analyze a repository
aga analyze https://github.com/username/repo
```

---

## Configuration

Create a `.env` file in your project root:

```env
GITHUB_TOKEN=ghp_...
GROQ_API_KEY=gsk_...
```

---

## Usage

### 1. Authentication Tab
Enter your GitHub Personal Access Token and Groq API Key to initialize the platform.

### 2. Repo Manager Tab
- Sync your repositories
- Navigate folders with the file explorer
- Upload and deploy files with AI-generated commit messages

### 3. Deep Analyzer Tab
Paste a GitHub repo URL and get:
- Health, Security, and Documentation scores
- A detailed AI architectural report

### 4. Smart README Tab
Paste your project structure or summary and generate a README in your preferred style.

### 5. Repo Creator Tab
Create a new GitHub repository directly without leaving the app.

---

## License

MIT
